﻿[System.Serializable]
public class CLSCMiscStats
{
    public long TimePlayed { get; set; }
    public long TimeStarted { get; set; }
    
    public int Difficulty { get; }
    public int FeverUpTime { get; set; }
}