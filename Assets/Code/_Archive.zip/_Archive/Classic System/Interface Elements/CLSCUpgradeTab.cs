using UnityEngine.UI;

public class CLSCUpgradeTab
{
    public UpgradeType type;
    public Button button;
    public Text text;
    public Image image;
}