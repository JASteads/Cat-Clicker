using UnityEngine;
using UnityEngine.UI;

public class CLSCFeverMeter
{
    public RectTransform transform;
    public Image feverBar;
}