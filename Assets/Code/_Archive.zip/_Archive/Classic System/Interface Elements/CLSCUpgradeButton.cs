using UnityEngine;
using UnityEngine.UI;

public class CLSCUpgradeButton
{
    public UpgradeData data;
    public RectTransform rectTf;
    public Button button;
    public Text title, price;
    public Image buttonImage, icon;
}