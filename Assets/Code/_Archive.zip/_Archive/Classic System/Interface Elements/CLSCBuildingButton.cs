using UnityEngine.UI;

public class CLSCBuildingButton
{
    public Image image;
    public Button button;
    public Text name, price, count;
    public bool active;
}